import ProductList from "./components/ProductList/ProductList"



const App =() =>{
  return (
      <div>

       <ProductList/> 

      </div>
        
  )
}

export default App
