// import 
// const Home = () =>{
//     return(
//         <div>
//             <Profile name="Name: Bola Oduleke" age="Age: 31 years old" location="Location:Lagos,Nigeria" profileImage={logo} color="bg-card-1" text="Dark Mode" theme= "botton1" />
//             <Profile name="Name: Olusegun Seyi" age="Age: 25 years old" location="Location:Ibadan,Nigeria" profileImage={logo} color="bg-card-2" text="Dark Mode" theme= "botton1" />
//             <Profile name="Name: Tinuola Fatimah" age="Age: 14 years old" location="Location: Abuja,Nigeria" profileImage={logo} color="bg-card-3" text="Dark Mode" theme= "botton1" />
//             <Profile name="Name: Omolola Oduniyi" age="Age: 27 years old" location="Location: Osogbo,Nigeria" profileImage={logo} color="bg-card-4" text="Dark Mode" theme= "botton1" />
//             <Profile name="Name: Odumodu Goodness" age="Age: 28 years old" location="Location: Ondo,Nigeria" profileImage={logo} color="bg-card-5" text="Dark Mode" theme= "botton1" />
//             <Profile name="Name: Simioluwa Tunde" age="Age: 31 years old" location="Location: Ilorin,Nigeria" profileImage={logo} color="bg-card-6" text="Dark Mode" theme= "botton1" />
//         </div>
//     )
// };

export default Home;