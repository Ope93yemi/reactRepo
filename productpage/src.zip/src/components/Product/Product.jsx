import "./Product.css"

const Product = (props) =>{


    return(
        <div>
            <div className={`Products ${props.style}`}>
                <h1>{props.productName}</h1>
                <p>{props.price}</p>
                <img src={props.imageUrl} alt="productimage" />
                <p>{props.description}</p>
                
            </div>
        </div>
    )
};

export default Product